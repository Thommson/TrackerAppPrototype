// connectionString for your database
const connectionString = {
	user: 'Group9',
	password: 'zTrbqfreapCs7mNe',
	server: 'des-sql.ucn.dk\\DESSTUD',
  database: 'Group9'
};

module.exports = connectionString;

/*
const connectionString = {
	user: '<your username>',
	password: '<your password>',
	server: 'des-sql.ucn.dk\\DESSTUD',
	database: '<your username>'
};
*/
